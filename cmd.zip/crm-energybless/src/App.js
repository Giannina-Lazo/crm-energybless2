import { useState, useEffect, useRef } from "react";
import { supabase } from "./supabase";

// ─── PALETA ──────────────────────────────────────────────────────────────────
const C = {
  bg: "#0A0C10", surface: "#12161C", border: "#1E2530", hover: "#1A2030",
  gold: "#C9962A", goldLight: "#E4B84A", blue: "#2563EB", blueLight: "#3B82F6",
  green: "#16A34A", red: "#DC2626", purple: "#7C3AED", amber: "#D97706",
  text: "#E2E8F0", muted: "#64748B", subtle: "#334155",
};

const USUARIOS = [
  { id: 0, nombre: "Giannina",       rol: "gerente", pass: "eb2026",    avatar: "G"  },
  { id: 1, nombre: "Carlos Muñoz",   rol: "asesor",  pass: "carlos123", avatar: "CM" },
  { id: 2, nombre: "Valentina Soto", rol: "asesor",  pass: "valen123",  avatar: "VS" },
  { id: 3, nombre: "Rodrigo Fuentes",rol: "asesor",  pass: "rodri123",  avatar: "RF" },
];
const ASESORES = USUARIOS.filter(u => u.rol === "asesor");

const PROYECTOS = [
  { id: 1, nombre: "Costa Dorada",      ubicacion: "Llico",    total: 80, disponibles: 42, precio: 18500000, estado: "Activo" },
  { id: 2, nombre: "Praderas de Caone", ubicacion: "Caone",    total: 60, disponibles: 31, precio: 14900000, estado: "Activo" },
  { id: 3, nombre: "Valle Verde",       ubicacion: "Rancagua", total: 40, disponibles: 18, precio: 22000000, estado: "Activo" },
];

const ESTADOS = ["Nuevo","Contactado","Visita agendada","En negociación","Reserva","Escritura","Perdido"];
const ECOLOR  = { "Nuevo":C.blue,"Contactado":C.purple,"Visita agendada":C.amber,"En negociación":C.red,"Reserva":C.green,"Escritura":"#059669","Perdido":C.muted };

const fmt   = n => new Intl.NumberFormat("es-CL",{style:"currency",currency:"CLP",maximumFractionDigits:0}).format(n);
const today = () => new Date().toISOString().split("T")[0];

// ─── ESTILOS ─────────────────────────────────────────────────────────────────
const B = {
  app:    { fontFamily:"'DM Sans',sans-serif", background:C.bg, color:C.text, minHeight:"100vh", display:"flex" },
  side:   w => ({ width:w, background:C.surface, borderRight:`1px solid ${C.border}`, display:"flex", flexDirection:"column", transition:"width 0.25s", flexShrink:0, overflow:"hidden" }),
  main:   { flex:1, display:"flex", flexDirection:"column", overflow:"hidden", minWidth:0 },
  hdr:    { background:C.surface, borderBottom:`1px solid ${C.border}`, padding:"14px 24px", display:"flex", alignItems:"center", justifyContent:"space-between", flexShrink:0 },
  cnt:    { flex:1, overflow:"auto", padding:24 },
  card:   { background:C.surface, border:`1px solid ${C.border}`, borderRadius:12, padding:20 },
  inp:    { background:C.bg, border:`1px solid ${C.border}`, borderRadius:8, padding:"9px 12px", color:C.text, fontSize:13, width:"100%", outline:"none", boxSizing:"border-box", fontFamily:"'DM Sans',sans-serif" },
  lbl:    { fontSize:11, color:C.muted, fontWeight:700, textTransform:"uppercase", letterSpacing:0.5, marginBottom:5, display:"block" },
  frow:   { marginBottom:14 },
  tbl:    { width:"100%", borderCollapse:"collapse", fontSize:13 },
  th:     { textAlign:"left", padding:"9px 12px", color:C.muted, fontWeight:700, fontSize:11, textTransform:"uppercase", letterSpacing:0.5, borderBottom:`1px solid ${C.border}` },
  td:     { padding:"11px 12px", borderBottom:`1px solid ${C.border}20`, verticalAlign:"middle" },
  modal:  { position:"fixed", inset:0, background:"#00000085", display:"flex", alignItems:"center", justifyContent:"center", zIndex:200, backdropFilter:"blur(3px)" },
  mbox:   { background:C.surface, border:`1px solid ${C.border}`, borderRadius:16, padding:28, width:500, maxHeight:"88vh", overflowY:"auto" },
};
const btn  = (color=C.blue,size="md") => ({ background:color, color:"#fff", border:"none", borderRadius:8, padding:size==="sm"?"5px 12px":"9px 18px", cursor:"pointer", fontSize:size==="sm"?12:13, fontWeight:600, display:"inline-flex", alignItems:"center", gap:6, fontFamily:"'DM Sans',sans-serif" });
const bgo  = { background:"transparent", color:C.muted, border:`1px solid ${C.border}`, borderRadius:8, padding:"9px 16px", cursor:"pointer", fontSize:13, fontFamily:"'DM Sans',sans-serif" };
const bdg  = color => ({ background:color+"18", color, border:`1px solid ${color}35`, borderRadius:20, padding:"3px 10px", fontSize:11, fontWeight:700, display:"inline-block", whiteSpace:"nowrap" });
const tg   = color => ({ background:color+"15", color, fontSize:11, padding:"2px 8px", borderRadius:4, fontWeight:600, display:"inline-block" });

// ─── LOGIN ────────────────────────────────────────────────────────────────────
function Login({ onLogin }) {
  const [user,setUser]=useState(""); const [pass,setPass]=useState(""); const [err,setErr]=useState("");
  const go = () => {
    const f = USUARIOS.find(u=>u.nombre.toLowerCase()===user.toLowerCase()&&u.pass===pass);
    if(f){setErr("");onLogin(f);}else setErr("Usuario o contraseña incorrectos.");
  };
  return (
    <div style={{minHeight:"100vh",background:C.bg,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'DM Sans',sans-serif"}}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"/>
      <div style={{background:C.surface,border:`1px solid ${C.border}`,borderRadius:20,padding:40,width:380,textAlign:"center"}}>
        <div style={{width:56,height:56,background:`linear-gradient(135deg,${C.gold},${C.goldLight})`,borderRadius:14,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:900,fontSize:22,color:C.bg,margin:"0 auto 20px"}}>EB</div>
        <div style={{fontSize:20,fontWeight:800,marginBottom:4}}>Propiedades Energy Bless</div>
        <div style={{fontSize:13,color:C.muted,marginBottom:28}}>CRM Inmobiliario · División Parcelas</div>
        <div style={{textAlign:"left",marginBottom:14}}>
          <label style={B.lbl}>Usuario</label>
          <input style={B.inp} placeholder="Tu nombre" value={user} onChange={e=>setUser(e.target.value)} onKeyDown={e=>e.key==="Enter"&&go()}/>
        </div>
        <div style={{textAlign:"left",marginBottom:20}}>
          <label style={B.lbl}>Contraseña</label>
          <input style={B.inp} type="password" placeholder="••••••••" value={pass} onChange={e=>setPass(e.target.value)} onKeyDown={e=>e.key==="Enter"&&go()}/>
        </div>
        {err&&<div style={{fontSize:12,color:C.red,marginBottom:14}}>{err}</div>}
        <button style={{...btn(C.gold),width:"100%",justifyContent:"center",color:C.bg}} onClick={go}>Ingresar →</button>
      </div>
    </div>
  );
}

// ─── PANEL ASESOR ─────────────────────────────────────────────────────────────
function PanelAsesor({usuario,onLogout}){
  const [tareas,setTareas]=useState([]);
  const [loading,setLoading]=useState(true);
  const [tab,setTab]=useState("pendientes");

  useEffect(()=>{
    const load = async()=>{
      setLoading(true);
      const{data}=await supabase.from("tareas").select("*").eq("asesor_id",usuario.id).order("fecha");
      setTareas(data||[]);
      setLoading(false);
    };
    load();
  },[usuario.id]);

  const toggle = async(t)=>{
    const nuevo=!t.completada;
    await supabase.from("tareas").update({completada:nuevo,estado:nuevo?"Completada":"Pendiente"}).eq("id",t.id);
    setTareas(prev=>prev.map(x=>x.id===t.id?{...x,completada:nuevo,estado:nuevo?"Completada":"Pendiente"}:x));
  };

  const pend=tareas.filter(t=>!t.completada);
  const comp=tareas.filter(t=>t.completada);
  const pct=tareas.length>0?Math.round((comp.length/tareas.length)*100):0;
  const PC={"Alta":C.red,"Media":C.amber,"Baja":C.green};

  return(
    <div style={{...B.app,flexDirection:"column"}}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"/>
      <div style={B.hdr}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <div style={{width:36,height:36,background:`linear-gradient(135deg,${C.gold},${C.goldLight})`,borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:13,color:C.bg}}>{usuario.avatar}</div>
          <div><div style={{fontWeight:700,fontSize:15}}>{usuario.nombre}</div><div style={{fontSize:11,color:C.muted}}>Asesor Comercial · Energy Bless</div></div>
        </div>
        <button style={bgo} onClick={onLogout}>Cerrar sesión</button>
      </div>
      <div style={{...B.cnt,maxWidth:680,margin:"0 auto",width:"100%"}}>
        <div style={{marginBottom:24}}>
          <div style={{fontSize:22,fontWeight:800}}>Mis Tareas del Día</div>
          <div style={{fontSize:13,color:C.muted,marginTop:4}}>Asignadas por tu supervisora · {today()}</div>
        </div>
        <div style={{display:"flex",gap:10,marginBottom:20}}>
          {[["pendientes","Pendientes",pend.length],["hechas","Completadas",comp.length]].map(([id,label,cnt])=>(
            <button key={id} onClick={()=>setTab(id)} style={{background:tab===id?C.gold:C.surface,color:tab===id?C.bg:C.muted,border:`1px solid ${tab===id?C.gold:C.border}`,borderRadius:8,padding:"8px 18px",cursor:"pointer",fontWeight:700,fontSize:13,display:"flex",alignItems:"center",gap:8,fontFamily:"'DM Sans',sans-serif"}}>
              {label}<span style={{background:tab===id?C.bg+"30":C.border,borderRadius:99,padding:"1px 8px",fontSize:12,fontWeight:700,color:tab===id?C.bg:C.text}}>{cnt}</span>
            </button>
          ))}
        </div>
        {loading&&<div style={{textAlign:"center",color:C.muted,padding:40}}>Cargando tareas...</div>}
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          {!loading&&(tab==="pendientes"?pend:comp).length===0&&(
            <div style={{...B.card,textAlign:"center",color:C.muted,padding:40}}>{tab==="pendientes"?"✓ Sin tareas pendientes":"Aún no has completado tareas"}</div>
          )}
          {(tab==="pendientes"?pend:comp).map(t=>(
            <div key={t.id} style={{...B.card,borderLeft:`4px solid ${PC[t.prioridad]||C.blue}`,display:"flex",gap:16,alignItems:"flex-start"}}>
              <div style={{paddingTop:2,cursor:"pointer"}} onClick={()=>toggle(t)}>
                <div style={{width:22,height:22,borderRadius:6,border:`2px solid ${t.completada?C.green:C.border}`,background:t.completada?C.green:"transparent",display:"flex",alignItems:"center",justifyContent:"center"}}>
                  {t.completada&&<span style={{color:"#fff",fontSize:13,fontWeight:900}}>✓</span>}
                </div>
              </div>
              <div style={{flex:1}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:6}}>
                  <div style={{fontWeight:700,fontSize:14,textDecoration:t.completada?"line-through":"none",color:t.completada?C.muted:C.text}}>{t.titulo}</div>
                  <span style={bdg(PC[t.prioridad]||C.blue)}>{t.prioridad}</span>
                </div>
                {t.descripcion&&<div style={{fontSize:13,color:C.muted,lineHeight:1.5}}>{t.descripcion}</div>}
                <div style={{fontSize:11,color:C.subtle,marginTop:8}}>📅 {t.fecha}</div>
              </div>
            </div>
          ))}
        </div>
        <div style={{...B.card,marginTop:24,background:C.bg,textAlign:"center"}}>
          <div style={{fontSize:13,color:C.muted}}>Progreso del día: <span style={{color:C.gold,fontWeight:700}}>{pct}%</span></div>
          <div style={{height:8,background:C.border,borderRadius:99,marginTop:8}}>
            <div style={{height:8,width:pct+"%",background:`linear-gradient(90deg,${C.gold},${C.goldLight})`,borderRadius:99,transition:"width 0.4s"}}/>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── CRM GERENTE ─────────────────────────────────────────────────────────────
export default function App(){
  const [usuario,setUsuario]=useState(null);
  const [tab,setTab]=useState("dashboard");
  const [sideOpen,setSideOpen]=useState(true);
  const [leads,setLeads]=useState([]);
  const [visitas,setVisitas]=useState([]);
  const [reservas,setReservas]=useState([]);
  const [tareas,setTareas]=useState([]);
  const [loading,setLoading]=useState(true);

  // modales
  const [mLead,setMLead]=useState(false);
  const [mVisita,setMVisita]=useState(false);
  const [mReserva,setMReserva]=useState(false);
  const [mTarea,setMTarea]=useState(false);
  const [editItem,setEditItem]=useState(null);

  const eL={nombre:"",telefono:"",email:"",origen:"Instagram",proyecto:"Costa Dorada",asesor_id:1,estado:"Nuevo",notas:""};
  const eV={lead_id:"",asesor_id:1,proyecto:"Costa Dorada",fecha:today(),hora:"10:00",estado:"Pendiente",resultado:""};
  const eR={lead_id:"",asesor_id:1,proyecto:"Costa Dorada",parcela:"",monto:0,fecha_reserva:today(),estado:"Reserva",escritura_fecha:"",notas:""};
  const eT={asesor_id:1,titulo:"",descripcion:"",prioridad:"Media",fecha:today(),estado:"Pendiente",completada:false};
  const [fL,setFL]=useState(eL);
  const [fV,setFV]=useState(eV);
  const [fR,setFR]=useState(eR);
  const [fT,setFT]=useState(eT);

  // IA
  const [aiChat,setAiChat]=useState([]);
  const [aiInput,setAiInput]=useState("");
  const [aiLoad,setAiLoad]=useState(false);
  const chatRef=useRef(null);
  useEffect(()=>{chatRef.current?.scrollIntoView({behavior:"smooth"});},[aiChat]);

  // ── CARGA DE DATOS ──────────────────────────────────────────────
  const loadAll = async()=>{
    setLoading(true);
    const [l,v,r,t]=await Promise.all([
      supabase.from("leads").select("*").order("created_at",{ascending:false}),
      supabase.from("visitas").select("*").order("fecha"),
      supabase.from("reservas").select("*").order("fecha_reserva",{ascending:false}),
      supabase.from("tareas").select("*").order("fecha"),
    ]);
    setLeads(l.data||[]);
    setVisitas(v.data||[]);
    setReservas(r.data||[]);
    setTareas(t.data||[]);
    setLoading(false);
  };

  useEffect(()=>{ if(usuario?.rol==="gerente") loadAll(); },[usuario]);

  if(!usuario) return <Login onLogin={setUsuario}/>;
  if(usuario.rol==="asesor") return <PanelAsesor usuario={usuario} onLogout={()=>setUsuario(null)}/>;

  // ── MÉTRICAS ────────────────────────────────────────────────────
  const totalLeads=leads.length;
  const resAct=reservas.filter(r=>r.estado==="Reserva").length;
  const escrAct=reservas.filter(r=>r.estado==="Escritura").length;
  const conv=totalLeads>0?Math.round(((resAct+escrAct)/totalLeads)*100):0;
  const aNombre=id=>ASESORES.find(a=>a.id===Number(id))?.nombre||"–";
  const lNombre=id=>leads.find(l=>l.id===Number(id))?.nombre||"–";

  // ── CRUD LEADS ──────────────────────────────────────────────────
  const saveLead=async()=>{
    if(!fL.nombre||!fL.telefono) return;
    if(editItem){
      await supabase.from("leads").update(fL).eq("id",editItem.id);
    } else {
      await supabase.from("leads").insert({...fL,fecha:today()});
    }
    await loadAll(); setMLead(false); setEditItem(null); setFL(eL);
  };
  const delLead=async id=>{ await supabase.from("leads").delete().eq("id",id); await loadAll(); };

  // ── CRUD VISITAS ─────────────────────────────────────────────────
  const saveVisita=async()=>{
    if(!fV.fecha) return;
    await supabase.from("visitas").insert(fV);
    await loadAll(); setMVisita(false); setFV(eV);
  };

  // ── CRUD RESERVAS ────────────────────────────────────────────────
  const saveReserva=async()=>{
    if(!fR.parcela||!fR.fecha_reserva) return;
    await supabase.from("reservas").insert({...fR,escritura_fecha:fR.escritura_fecha||null});
    await loadAll(); setMReserva(false); setFR(eR);
  };

  // ── CRUD TAREAS ──────────────────────────────────────────────────
  const saveTarea=async()=>{
    if(!fT.titulo) return;
    if(editItem){
      await supabase.from("tareas").update(fT).eq("id",editItem.id);
    } else {
      await supabase.from("tareas").insert(fT);
    }
    await loadAll(); setMTarea(false); setEditItem(null); setFT(eT);
  };
  const delTarea=async id=>{ await supabase.from("tareas").delete().eq("id",id); await loadAll(); };

  // ── IA ───────────────────────────────────────────────────────────
  const sendAI=async()=>{
    if(!aiInput.trim()) return;
    const msg=aiInput.trim(); setAiInput("");
    setAiChat(p=>[...p,{role:"user",text:msg}]);
    setAiLoad(true);
    const ctx=`Eres el asistente IA del CRM de Propiedades Energy Bless, inmobiliaria chilena de parcelas rurales. Datos actuales: ${totalLeads} leads, ${leads.filter(l=>l.estado==="Nuevo").length} nuevos, ${resAct} reservas, ${escrAct} escrituras, conversión ${conv}%. Proyectos: ${PROYECTOS.map(p=>`${p.nombre} (${p.disponibles}/${p.total} disponibles)`).join(", ")}. Responde en español, conciso y orientado a ventas inmobiliarias.`;
    try{
      const res=await fetch("https://api.anthropic.com/v1/messages",{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,system:ctx,
          messages:[...aiChat.map(m=>({role:m.role==="user"?"user":"assistant",content:m.text})),{role:"user",content:msg}]})
      });
      const data=await res.json();
      setAiChat(p=>[...p,{role:"assistant",text:data.content?.map(c=>c.text||"").join("")||"Sin respuesta."}]);
    }catch{ setAiChat(p=>[...p,{role:"assistant",text:"Error de conexión."}]); }
    setAiLoad(false);
  };

  const TABS=[
    {id:"dashboard",icon:"⬡",label:"Dashboard"},
    {id:"leads",icon:"◎",label:"Leads"},
    {id:"pipeline",icon:"◈",label:"Pipeline"},
    {id:"visitas",icon:"◷",label:"Visitas"},
    {id:"reservas",icon:"◉",label:"Reservas"},
    {id:"tareas",icon:"✔",label:"Tareas"},
    {id:"asesores",icon:"◑",label:"Asesores"},
    {id:"proyectos",icon:"◧",label:"Proyectos"},
    {id:"ia",icon:"✦",label:"Asistente IA"},
  ];

  // ══ RENDERS ══════════════════════════════════════════════════════

  const renderDashboard=()=>(
    <div>
      <div style={{marginBottom:24}}><div style={{fontSize:24,fontWeight:800}}>Bienvenida, Giannina 👋</div><div style={{fontSize:13,color:C.muted,marginTop:4}}>Panel General · {today()}</div></div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:16,marginBottom:24}}>
        {[{label:"Total Leads",val:totalLeads,color:C.blue,sub:`${leads.filter(l=>l.estado==="Nuevo").length} nuevos`},{label:"Reservas",val:resAct,color:C.green,sub:"vigentes"},{label:"Escrituras",val:escrAct,color:C.goldLight,sub:"cerradas"},{label:"Conversión",val:conv+"%",color:C.gold,sub:"tasa general"}].map((m,i)=>(
          <div key={i} style={{...B.card,borderTop:`3px solid ${m.color}`}}>
            <div style={{fontSize:11,color:C.muted,fontWeight:700,textTransform:"uppercase",letterSpacing:1,marginBottom:8}}>{m.label}</div>
            <div style={{fontSize:34,fontWeight:900,color:m.color,lineHeight:1}}>{m.val}</div>
            <div style={{fontSize:12,color:C.subtle,marginTop:6}}>{m.sub}</div>
          </div>
        ))}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16,marginBottom:16}}>
        <div style={B.card}>
          <div style={{fontWeight:700,fontSize:14,marginBottom:16}}>Pipeline</div>
          {ESTADOS.filter(e=>e!=="Perdido").map(est=>{
            const cnt=leads.filter(l=>l.estado===est).length;
            const pct=totalLeads>0?Math.round((cnt/totalLeads)*100):0;
            return(<div key={est} style={{marginBottom:10}}>
              <div style={{display:"flex",justifyContent:"space-between",fontSize:12,marginBottom:3}}><span>{est}</span><span style={{color:ECOLOR[est],fontWeight:700}}>{cnt}</span></div>
              <div style={{height:5,background:C.border,borderRadius:99}}><div style={{height:5,width:pct+"%",background:ECOLOR[est],borderRadius:99}}/></div>
            </div>);
          })}
        </div>
        <div style={B.card}>
          <div style={{fontWeight:700,fontSize:14,marginBottom:16}}>Proyectos</div>
          {PROYECTOS.map(p=>{
            const pct=Math.round((p.disponibles/p.total)*100);
            return(<div key={p.id} style={{marginBottom:14}}>
              <div style={{display:"flex",justifyContent:"space-between",fontSize:12,marginBottom:3}}><span style={{fontWeight:600}}>{p.nombre}</span><span style={{color:C.gold,fontWeight:700}}>{p.disponibles}/{p.total}</span></div>
              <div style={{height:7,background:C.border,borderRadius:99}}><div style={{height:7,width:pct+"%",background:`linear-gradient(90deg,${C.gold},${C.goldLight})`,borderRadius:99}}/></div>
              <div style={{fontSize:11,color:C.muted,marginTop:2}}>{fmt(p.precio)} base</div>
            </div>);
          })}
        </div>
      </div>
      <div style={B.card}>
        <div style={{fontWeight:700,fontSize:14,marginBottom:16}}>Tareas Pendientes</div>
        {tareas.filter(t=>!t.completada).slice(0,5).map(t=>(
          <div key={t.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 0",borderBottom:`1px solid ${C.border}20`}}>
            <div><div style={{fontSize:13,fontWeight:600}}>{t.titulo}</div><div style={{fontSize:11,color:C.muted}}>{aNombre(t.asesor_id)} · {t.fecha}</div></div>
            <span style={bdg({Alta:C.red,Media:C.amber,Baja:C.green}[t.prioridad])}>{t.prioridad}</span>
          </div>
        ))}
        {tareas.filter(t=>!t.completada).length===0&&<div style={{fontSize:13,color:C.muted}}>✓ Sin tareas pendientes</div>}
      </div>
    </div>
  );

  const renderLeads=()=>(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:24}}>
        <div><div style={{fontSize:22,fontWeight:800}}>Leads / Prospectos</div><div style={{fontSize:13,color:C.muted}}>{totalLeads} registros</div></div>
        <button style={btn()} onClick={()=>{setEditItem(null);setFL(eL);setMLead(true);}}>+ Nuevo Lead</button>
      </div>
      {loading?<div style={{textAlign:"center",color:C.muted,padding:40}}>Cargando...</div>:
      <div style={B.card}>
        <table style={B.tbl}>
          <thead><tr>{["Nombre","Teléfono","Origen","Proyecto","Asesor","Estado","Fecha",""].map(h=><th key={h} style={B.th}>{h}</th>)}</tr></thead>
          <tbody>{leads.map(l=>(
            <tr key={l.id}>
              <td style={B.td}><b>{l.nombre}</b><br/><span style={{fontSize:11,color:C.muted}}>{l.email}</span></td>
              <td style={B.td}>{l.telefono}</td>
              <td style={B.td}><span style={tg(C.purple)}>{l.origen}</span></td>
              <td style={B.td}>{l.proyecto}</td>
              <td style={B.td}>{aNombre(l.asesor_id)}</td>
              <td style={B.td}><span style={bdg(ECOLOR[l.estado]||C.muted)}>{l.estado}</span></td>
              <td style={B.td}>{l.fecha}</td>
              <td style={B.td}><div style={{display:"flex",gap:6}}>
                <button style={btn(C.blue,"sm")} onClick={()=>{setEditItem(l);setFL({nombre:l.nombre,telefono:l.telefono,email:l.email||"",origen:l.origen,proyecto:l.proyecto,asesor_id:l.asesor_id,estado:l.estado,notas:l.notas||""});setMLead(true);}}>Editar</button>
                <button style={btn(C.red,"sm")} onClick={()=>delLead(l.id)}>✕</button>
              </div></td>
            </tr>
          ))}</tbody>
        </table>
      </div>}
    </div>
  );

  const renderPipeline=()=>(
    <div>
      <div style={{marginBottom:24}}><div style={{fontSize:22,fontWeight:800}}>Pipeline de Ventas</div><div style={{fontSize:13,color:C.muted}}>Flujo por etapa</div></div>
      <div style={{display:"flex",gap:12,overflowX:"auto",paddingBottom:8}}>
        {ESTADOS.map(est=>{
          const col=leads.filter(l=>l.estado===est);
          return(<div key={est} style={{background:C.bg,border:`1px solid ${C.border}`,borderRadius:10,padding:12,minWidth:170,flexShrink:0}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:10}}>
              <div style={{fontSize:11,fontWeight:700,color:ECOLOR[est],textTransform:"uppercase",letterSpacing:0.5}}>{est}</div>
              <div style={{background:ECOLOR[est]+"20",color:ECOLOR[est],borderRadius:99,padding:"1px 8px",fontSize:12,fontWeight:700}}>{col.length}</div>
            </div>
            {col.length===0&&<div style={{fontSize:11,color:C.subtle,textAlign:"center",padding:"12px 0"}}>–</div>}
            {col.map(l=>(
              <div key={l.id} style={{background:C.surface,border:`1px solid ${C.border}`,borderLeft:`3px solid ${ECOLOR[est]}`,borderRadius:8,padding:"9px 10px",marginBottom:8}}>
                <div style={{fontWeight:600,fontSize:12}}>{l.nombre}</div>
                <div style={{fontSize:11,color:C.muted,marginTop:2}}>{l.proyecto}</div>
                <div style={{fontSize:11,color:C.blueLight,marginTop:2}}>{aNombre(l.asesor_id)}</div>
              </div>
            ))}
          </div>);
        })}
      </div>
    </div>
  );

  const renderVisitas=()=>(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:24}}>
        <div><div style={{fontSize:22,fontWeight:800}}>Visitas</div><div style={{fontSize:13,color:C.muted}}>{visitas.length} registradas</div></div>
        <button style={btn()} onClick={()=>setMVisita(true)}>+ Nueva Visita</button>
      </div>
      <div style={B.card}>
        <table style={B.tbl}>
          <thead><tr>{["Lead","Asesor","Proyecto","Fecha","Hora","Estado","Resultado"].map(h=><th key={h} style={B.th}>{h}</th>)}</tr></thead>
          <tbody>{visitas.map(v=>(
            <tr key={v.id}>
              <td style={B.td}><b>{lNombre(v.lead_id)}</b></td>
              <td style={B.td}>{aNombre(v.asesor_id)}</td>
              <td style={B.td}>{v.proyecto}</td>
              <td style={B.td}>{v.fecha}</td>
              <td style={B.td}>{v.hora}</td>
              <td style={B.td}><span style={bdg(v.estado==="Confirmada"?C.green:v.estado==="Realizada"?C.blue:C.amber)}>{v.estado}</span></td>
              <td style={B.td}><span style={{fontSize:12,color:C.muted}}>{v.resultado||"–"}</span></td>
            </tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );

  const renderReservas=()=>(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:24}}>
        <div><div style={{fontSize:22,fontWeight:800}}>Reservas y Escrituras</div><div style={{fontSize:13,color:C.muted}}>{reservas.length} operaciones</div></div>
        <button style={btn(C.green)} onClick={()=>setMReserva(true)}>+ Nueva Reserva</button>
      </div>
      <div style={B.card}>
        <table style={B.tbl}>
          <thead><tr>{["Cliente","Asesor","Proyecto","Parcela","Monto","Fecha","Estado","Escritura"].map(h=><th key={h} style={B.th}>{h}</th>)}</tr></thead>
          <tbody>{reservas.map(r=>(
            <tr key={r.id}>
              <td style={B.td}><b>{lNombre(r.lead_id)}</b></td>
              <td style={B.td}>{aNombre(r.asesor_id)}</td>
              <td style={B.td}>{r.proyecto}</td>
              <td style={B.td}><span style={tg(C.gold)}>{r.parcela}</span></td>
              <td style={B.td}><span style={{color:C.green,fontWeight:700}}>{fmt(r.monto)}</span></td>
              <td style={B.td}>{r.fecha_reserva}</td>
              <td style={B.td}><span style={bdg(r.estado==="Escritura"?C.green:C.gold)}>{r.estado}</span></td>
              <td style={B.td}><span style={{fontSize:12,color:C.muted}}>{r.escritura_fecha||"Pendiente"}</span></td>
            </tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );

  const renderTareas=()=>(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:24}}>
        <div><div style={{fontSize:22,fontWeight:800}}>Tareas para Asesores</div><div style={{fontSize:13,color:C.muted}}>Asigna tareas diarias a tu equipo</div></div>
        <button style={btn(C.gold)} onClick={()=>{setEditItem(null);setFT(eT);setMTarea(true);}}>+ Asignar Tarea</button>
      </div>
      {ASESORES.map(a=>{
        const ats=tareas.filter(t=>t.asesor_id===a.id);
        const comp=ats.filter(t=>t.completada).length;
        const PC={Alta:C.red,Media:C.amber,Baja:C.green};
        return(<div key={a.id} style={{...B.card,marginBottom:16}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <div style={{width:36,height:36,background:`linear-gradient(135deg,${C.blue},${C.blueLight})`,borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:12,color:"#fff"}}>{a.avatar}</div>
              <div><div style={{fontWeight:700}}>{a.nombre}</div><div style={{fontSize:12,color:C.muted}}>{ats.filter(t=>!t.completada).length} pendientes · {comp} completadas</div></div>
            </div>
            <div style={{height:6,width:120,background:C.border,borderRadius:99,overflow:"hidden"}}>
              <div style={{height:6,width:(ats.length>0?Math.round((comp/ats.length)*100):0)+"%",background:C.green,borderRadius:99}}/>
            </div>
          </div>
          {ats.length===0&&<div style={{fontSize:13,color:C.subtle,padding:"8px 0"}}>Sin tareas asignadas</div>}
          <div style={{display:"flex",flexDirection:"column",gap:8}}>
            {ats.map(t=>(
              <div key={t.id} style={{background:C.bg,border:`1px solid ${C.border}`,borderLeft:`3px solid ${PC[t.prioridad]}`,borderRadius:8,padding:"10px 14px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <div>
                  <div style={{fontSize:13,fontWeight:600,textDecoration:t.completada?"line-through":"none",color:t.completada?C.muted:C.text}}>{t.titulo}</div>
                  {t.descripcion&&<div style={{fontSize:12,color:C.muted,marginTop:2}}>{t.descripcion}</div>}
                  <div style={{fontSize:11,color:C.subtle,marginTop:4}}>📅 {t.fecha} · <span style={bdg(PC[t.prioridad])}>{t.prioridad}</span></div>
                </div>
                <div style={{display:"flex",gap:6,flexShrink:0,marginLeft:12}}>
                  <span style={bdg(t.completada?C.green:C.amber)}>{t.completada?"✓ Hecha":"Pendiente"}</span>
                  <button style={btn(C.blue,"sm")} onClick={()=>{setEditItem(t);setFT({asesor_id:t.asesor_id,titulo:t.titulo,descripcion:t.descripcion||"",prioridad:t.prioridad,fecha:t.fecha,estado:t.estado,completada:t.completada});setMTarea(true);}}>Editar</button>
                  <button style={btn(C.red,"sm")} onClick={()=>delTarea(t.id)}>✕</button>
                </div>
              </div>
            ))}
          </div>
        </div>);
      })}
    </div>
  );

  const renderAsesores=()=>(
    <div>
      <div style={{marginBottom:24}}><div style={{fontSize:22,fontWeight:800}}>Asesores</div><div style={{fontSize:13,color:C.muted}}>{ASESORES.length} activos</div></div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:16}}>
        {ASESORES.map(a=>{
          const mL=leads.filter(l=>l.asesor_id===a.id);
          const mR=reservas.filter(r=>r.asesor_id===a.id);
          const mV=visitas.filter(v=>v.asesor_id===a.id);
          const mT=tareas.filter(t=>t.asesor_id===a.id&&!t.completada);
          return(<div key={a.id} style={{...B.card,borderTop:`3px solid ${C.gold}`}}>
            <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:16}}>
              <div style={{width:44,height:44,background:`linear-gradient(135deg,${C.gold},${C.goldLight})`,borderRadius:12,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:14,color:C.bg}}>{a.avatar}</div>
              <div><div style={{fontWeight:700,fontSize:15}}>{a.nombre}</div><span style={bdg(C.green)}>Activo</span></div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:12}}>
              {[["Leads",mL.length,C.blue],["Visitas",mV.length,C.purple],["Reservas",mR.length,C.green],["Tareas",mT.length,C.amber]].map(([l,v,c])=>(
                <div key={l} style={{background:C.bg,borderRadius:8,padding:"8px 10px"}}>
                  <div style={{fontSize:20,fontWeight:900,color:c}}>{v}</div>
                  <div style={{fontSize:10,color:C.muted,textTransform:"uppercase",letterSpacing:0.5}}>{l}</div>
                </div>
              ))}
            </div>
            <div style={{fontSize:11,color:C.muted,marginBottom:4}}>Conversión</div>
            <div style={{height:6,background:C.border,borderRadius:99}}>
              <div style={{height:6,width:(mL.length>0?Math.round((mR.length/mL.length)*100):0)+"%",background:`linear-gradient(90deg,${C.gold},${C.goldLight})`,borderRadius:99}}/>
            </div>
            <div style={{fontSize:12,color:C.gold,fontWeight:700,marginTop:4}}>{mL.length>0?Math.round((mR.length/mL.length)*100):0}%</div>
          </div>);
        })}
      </div>
    </div>
  );

  const renderProyectos=()=>(
    <div>
      <div style={{marginBottom:24}}><div style={{fontSize:22,fontWeight:800}}>Proyectos / Parcelas</div></div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:16}}>
        {PROYECTOS.map(p=>{
          const vend=p.total-p.disponibles;
          const pct=Math.round((vend/p.total)*100);
          return(<div key={p.id} style={{...B.card,borderTop:`3px solid ${C.blue}`}}>
            <div style={{fontWeight:800,fontSize:16,marginBottom:4}}>{p.nombre}</div>
            <div style={{fontSize:12,color:C.muted,marginBottom:16}}>📍 {p.ubicacion}</div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:14}}>
              {[["Total",p.total,C.muted],["Disponibles",p.disponibles,C.green],["Vendidas",vend,C.red],["Precio",fmt(p.precio),C.gold]].map(([l,v,c])=>(
                <div key={l} style={{background:C.bg,borderRadius:8,padding:"8px 10px"}}>
                  <div style={{fontSize:11,color:C.muted}}>{l}</div>
                  <div style={{fontSize:15,fontWeight:700,color:c}}>{v}</div>
                </div>
              ))}
            </div>
            <div style={{fontSize:11,color:C.muted,marginBottom:4}}>Avance · {pct}%</div>
            <div style={{height:8,background:C.border,borderRadius:99}}><div style={{height:8,width:pct+"%",background:`linear-gradient(90deg,${C.blue},${C.blueLight})`,borderRadius:99}}/></div>
            <div style={{marginTop:12}}><span style={bdg(C.green)}>{p.estado}</span></div>
          </div>);
        })}
      </div>
    </div>
  );

  const renderIA=()=>(
    <div style={{height:"calc(100vh - 130px)",display:"flex",flexDirection:"column"}}>
      <div style={{marginBottom:16}}><div style={{fontSize:22,fontWeight:800}}>Asistente IA</div><div style={{fontSize:13,color:C.muted}}>Análisis inteligente de tu CRM</div></div>
      <div style={{flex:1,display:"flex",flexDirection:"column",background:C.surface,border:`1px solid ${C.border}`,borderRadius:12,overflow:"hidden"}}>
        <div style={{flex:1,overflowY:"auto",padding:20,display:"flex",flexDirection:"column",gap:10}}>
          {aiChat.length===0&&(
            <div style={{textAlign:"center",color:C.muted,marginTop:32}}>
              <div style={{fontSize:36,marginBottom:10}}>✦</div>
              <div style={{fontWeight:700,fontSize:14,marginBottom:6}}>Asistente IA de Energy Bless</div>
              <div style={{display:"flex",flexWrap:"wrap",gap:8,justifyContent:"center",marginTop:16}}>
                {["¿Cómo va la conversión?","¿Qué asesor rinde mejor?","Estrategias para cerrar leads","¿Qué proyecto tiene más disponibilidad?"].map(q=>(
                  <button key={q} style={{background:C.bg,border:`1px solid ${C.border}`,borderRadius:20,padding:"6px 14px",fontSize:12,color:C.muted,cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}} onClick={()=>setAiInput(q)}>{q}</button>
                ))}
              </div>
            </div>
          )}
          {aiChat.map((m,i)=>(
            <div key={i} style={{maxWidth:"80%",alignSelf:m.role==="user"?"flex-end":"flex-start",background:m.role==="user"?C.blue:C.bg,border:`1px solid ${m.role==="user"?C.blue:C.border}`,borderRadius:m.role==="user"?"16px 16px 4px 16px":"16px 16px 16px 4px",padding:"10px 14px",fontSize:13,lineHeight:1.6,whiteSpace:"pre-wrap"}}>{m.text}</div>
          ))}
          {aiLoad&&<div style={{maxWidth:"80%",background:C.bg,border:`1px solid ${C.border}`,borderRadius:"16px 16px 16px 4px",padding:"10px 14px",fontSize:13,color:C.muted}}>Analizando datos...</div>}
          <div ref={chatRef}/>
        </div>
        <div style={{display:"flex",gap:8,padding:14,borderTop:`1px solid ${C.border}`}}>
          <input style={{...B.inp,flex:1}} placeholder="Pregunta sobre ventas, asesores, proyectos..." value={aiInput} onChange={e=>setAiInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&sendAI()}/>
          <button style={btn(C.gold)} onClick={sendAI} disabled={aiLoad}>{aiLoad?"...":"Enviar ✦"}</button>
        </div>
      </div>
    </div>
  );

  const tabMap={dashboard:renderDashboard,leads:renderLeads,pipeline:renderPipeline,visitas:renderVisitas,reservas:renderReservas,tareas:renderTareas,asesores:renderAsesores,proyectos:renderProyectos,ia:renderIA};

  // ══ RENDER PRINCIPAL ═══════════════════════════════════════════════════════
  return(
    <div style={B.app}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"/>

      {/* SIDEBAR */}
      <div style={B.side(sideOpen?230:60)}>
        <div style={{padding:sideOpen?"18px 16px 14px":"18px 10px 14px",borderBottom:`1px solid ${C.border}`,display:"flex",alignItems:"center",gap:10}}>
          <div style={{width:36,height:36,background:`linear-gradient(135deg,${C.gold},${C.goldLight})`,borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:900,fontSize:14,color:C.bg,flexShrink:0}}>EB</div>
          {sideOpen&&<div style={{fontSize:12,fontWeight:700,color:C.gold,lineHeight:1.3}}>Energy Bless<br/><span style={{fontWeight:400,color:C.muted,fontSize:11}}>CRM Inmobiliario</span></div>}
        </div>
        <nav style={{flex:1,padding:"10px 8px",display:"flex",flexDirection:"column",gap:3}}>
          {TABS.map(t=>(
            <div key={t.id} onClick={()=>setTab(t.id)} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 10px",borderRadius:8,cursor:"pointer",background:tab===t.id?C.blue+"18":"transparent",color:tab===t.id?C.blueLight:C.muted,fontWeight:tab===t.id?700:400,fontSize:13,border:tab===t.id?`1px solid ${C.blue}35`:"1px solid transparent",whiteSpace:"nowrap",overflow:"hidden",transition:"all 0.15s"}}>
              <span style={{fontSize:15,flexShrink:0}}>{t.icon}</span>
              {sideOpen&&t.label}
            </div>
          ))}
        </nav>
        <div style={{padding:"10px 8px",borderTop:`1px solid ${C.border}`}}>
          <div onClick={()=>setSideOpen(o=>!o)} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 10px",borderRadius:8,cursor:"pointer",color:C.muted,fontSize:13}}>
            <span style={{fontSize:15}}>{sideOpen?"◁":"▷"}</span>
            {sideOpen&&"Colapsar"}
          </div>
          <div onClick={()=>setUsuario(null)} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 10px",borderRadius:8,cursor:"pointer",color:C.red,fontSize:13}}>
            <span style={{fontSize:15}}>⏻</span>
            {sideOpen&&"Cerrar sesión"}
          </div>
        </div>
      </div>

      {/* MAIN */}
      <div style={B.main}>
        <div style={B.hdr}>
          <div style={{fontWeight:700,fontSize:15}}>{TABS.find(t=>t.id===tab)?.label}</div>
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            <div style={{fontSize:12,color:C.muted}}>División Parcelas · Propiedades Energy Bless</div>
            <div style={{width:32,height:32,background:`linear-gradient(135deg,${C.gold},${C.goldLight})`,borderRadius:8,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:12,color:C.bg}}>G</div>
          </div>
        </div>
        <div style={B.cnt}>{loading&&tab!=="ia"?<div style={{textAlign:"center",color:C.muted,padding:60,fontSize:14}}>Cargando datos...</div>:(tabMap[tab]||tabMap.dashboard)()}</div>
      </div>

      {/* MODAL LEAD */}
      {mLead&&(<div style={B.modal} onClick={e=>e.target===e.currentTarget&&setMLead(false)}>
        <div style={B.mbox}>
          <div style={{fontSize:17,fontWeight:800,marginBottom:20}}>{editItem?"Editar Lead":"Nuevo Lead"}</div>
          {[["Nombre completo","nombre","text"],["Teléfono","telefono","text"],["Email","email","email"]].map(([l,k,t])=>(
            <div key={k} style={B.frow}><label style={B.lbl}>{l}</label><input style={B.inp} type={t} value={fL[k]} onChange={e=>setFL(p=>({...p,[k]:e.target.value}))}/></div>
          ))}
          <div style={B.frow}><label style={B.lbl}>Origen</label><select style={B.inp} value={fL.origen} onChange={e=>setFL(p=>({...p,origen:e.target.value}))}>{["Instagram","Facebook","Portal web","Referido","WhatsApp","Llamada","Otro"].map(o=><option key={o}>{o}</option>)}</select></div>
          <div style={B.frow}><label style={B.lbl}>Proyecto</label><select style={B.inp} value={fL.proyecto} onChange={e=>setFL(p=>({...p,proyecto:e.target.value}))}>{PROYECTOS.map(p=><option key={p.id}>{p.nombre}</option>)}</select></div>
          <div style={B.frow}><label style={B.lbl}>Asesor asignado</label><select style={B.inp} value={fL.asesor_id} onChange={e=>setFL(p=>({...p,asesor_id:Number(e.target.value)}))}>{ASESORES.map(a=><option key={a.id} value={a.id}>{a.nombre}</option>)}</select></div>
          <div style={B.frow}><label style={B.lbl}>Estado</label><select style={B.inp} value={fL.estado} onChange={e=>setFL(p=>({...p,estado:e.target.value}))}>{ESTADOS.map(e=><option key={e}>{e}</option>)}</select></div>
          <div style={B.frow}><label style={B.lbl}>Notas</label><textarea style={{...B.inp,minHeight:70,resize:"vertical"}} value={fL.notas} onChange={e=>setFL(p=>({...p,notas:e.target.value}))}/></div>
          <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}><button style={bgo} onClick={()=>{setMLead(false);setEditItem(null);}}>Cancelar</button><button style={btn()} onClick={saveLead}>Guardar</button></div>
        </div>
      </div>)}

      {/* MODAL VISITA */}
      {mVisita&&(<div style={B.modal} onClick={e=>e.target===e.currentTarget&&setMVisita(false)}>
        <div style={B.mbox}>
          <div style={{fontSize:17,fontWeight:800,marginBottom:20}}>Nueva Visita</div>
          <div style={B.frow}><label style={B.lbl}>Lead / Cliente</label><select style={B.inp} value={fV.lead_id} onChange={e=>setFV(p=>({...p,lead_id:Number(e.target.value)}))}>{leads.map(l=><option key={l.id} value={l.id}>{l.nombre}</option>)}</select></div>
          <div style={B.frow}><label style={B.lbl}>Asesor</label><select style={B.inp} value={fV.asesor_id} onChange={e=>setFV(p=>({...p,asesor_id:Number(e.target.value)}))}>{ASESORES.map(a=><option key={a.id} value={a.id}>{a.nombre}</option>)}</select></div>
          <div style={B.frow}><label style={B.lbl}>Proyecto</label><select style={B.inp} value={fV.proyecto} onChange={e=>setFV(p=>({...p,proyecto:e.target.value}))}>{PROYECTOS.map(p=><option key={p.id}>{p.nombre}</option>)}</select></div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <div style={B.frow}><label style={B.lbl}>Fecha</label><input style={B.inp} type="date" value={fV.fecha} onChange={e=>setFV(p=>({...p,fecha:e.target.value}))}/></div>
            <div style={B.frow}><label style={B.lbl}>Hora</label><input style={B.inp} type="time" value={fV.hora} onChange={e=>setFV(p=>({...p,hora:e.target.value}))}/></div>
          </div>
          <div style={B.frow}><label style={B.lbl}>Estado</label><select style={B.inp} value={fV.estado} onChange={e=>setFV(p=>({...p,estado:e.target.value}))}>{["Pendiente","Confirmada","Realizada","No asistió"].map(o=><option key={o}>{o}</option>)}</select></div>
          <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}><button style={bgo} onClick={()=>setMVisita(false)}>Cancelar</button><button style={btn()} onClick={saveVisita}>Guardar</button></div>
        </div>
      </div>)}

      {/* MODAL RESERVA */}
      {mReserva&&(<div style={B.modal} onClick={e=>e.target===e.currentTarget&&setMReserva(false)}>
        <div style={B.mbox}>
          <div style={{fontSize:17,fontWeight:800,marginBottom:20}}>Nueva Reserva</div>
          <div style={B.frow}><label style={B.lbl}>Cliente</label><select style={B.inp} value={fR.lead_id} onChange={e=>setFR(p=>({...p,lead_id:Number(e.target.value)}))}>{leads.map(l=><option key={l.id} value={l.id}>{l.nombre}</option>)}</select></div>
          <div style={B.frow}><label style={B.lbl}>Asesor</label><select style={B.inp} value={fR.asesor_id} onChange={e=>setFR(p=>({...p,asesor_id:Number(e.target.value)}))}>{ASESORES.map(a=><option key={a.id} value={a.id}>{a.nombre}</option>)}</select></div>
          <div style={B.frow}><label style={B.lbl}>Proyecto</label><select style={B.inp} value={fR.proyecto} onChange={e=>setFR(p=>({...p,proyecto:e.target.value}))}>{PROYECTOS.map(p=><option key={p.id}>{p.nombre}</option>)}</select></div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <div style={B.frow}><label style={B.lbl}>N° Parcela</label><input style={B.inp} type="text" placeholder="Ej: CD-025" value={fR.parcela} onChange={e=>setFR(p=>({...p,parcela:e.target.value}))}/></div>
            <div style={B.frow}><label style={B.lbl}>Monto ($)</label><input style={B.inp} type="number" value={fR.monto} onChange={e=>setFR(p=>({...p,monto:Number(e.target.value)}))}/></div>
          </div>
          <div style={B.frow}><label style={B.lbl}>Fecha de Reserva</label><input style={B.inp} type="date" value={fR.fecha_reserva} onChange={e=>setFR(p=>({...p,fecha_reserva:e.target.value}))}/></div>
          <div style={B.frow}><label style={B.lbl}>Estado</label><select style={B.inp} value={fR.estado} onChange={e=>setFR(p=>({...p,estado:e.target.value}))}>{["Reserva","Escritura","Anulada"].map(o=><option key={o}>{o}</option>)}</select></div>
          <div style={B.frow}><label style={B.lbl}>Fecha Escritura (si aplica)</label><input style={B.inp} type="date" value={fR.escritura_fecha} onChange={e=>setFR(p=>({...p,escritura_fecha:e.target.value}))}/></div>
          <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}><button style={bgo} onClick={()=>setMReserva(false)}>Cancelar</button><button style={btn(C.green)} onClick={saveReserva}>Guardar</button></div>
        </div>
      </div>)}

      {/* MODAL TAREA */}
      {mTarea&&(<div style={B.modal} onClick={e=>e.target===e.currentTarget&&setMTarea(false)}>
        <div style={B.mbox}>
          <div style={{fontSize:17,fontWeight:800,marginBottom:20}}>{editItem?"Editar Tarea":"Asignar Tarea"}</div>
          <div style={B.frow}><label style={B.lbl}>Asesor</label><select style={B.inp} value={fT.asesor_id} onChange={e=>setFT(p=>({...p,asesor_id:Number(e.target.value)}))}>{ASESORES.map(a=><option key={a.id} value={a.id}>{a.nombre}</option>)}</select></div>
          <div style={B.frow}><label style={B.lbl}>Título de la tarea</label><input style={B.inp} type="text" placeholder="Ej: Llamar a cliente para confirmar visita" value={fT.titulo} onChange={e=>setFT(p=>({...p,titulo:e.target.value}))}/></div>
          <div style={B.frow}><label style={B.lbl}>Instrucciones</label><textarea style={{...B.inp,minHeight:80,resize:"vertical"}} placeholder="Detalla qué debe hacer el asesor..." value={fT.descripcion} onChange={e=>setFT(p=>({...p,descripcion:e.target.value}))}/></div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <div style={B.frow}><label style={B.lbl}>Prioridad</label><select style={B.inp} value={fT.prioridad} onChange={e=>setFT(p=>({...p,prioridad:e.target.value}))}>{["Alta","Media","Baja"].map(o=><option key={o}>{o}</option>)}</select></div>
            <div style={B.frow}><label style={B.lbl}>Fecha</label><input style={B.inp} type="date" value={fT.fecha} onChange={e=>setFT(p=>({...p,fecha:e.target.value}))}/></div>
          </div>
          <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}><button style={bgo} onClick={()=>{setMTarea(false);setEditItem(null);}}>Cancelar</button><button style={btn(C.gold)} onClick={saveTarea}>Guardar</button></div>
        </div>
      </div>)}
    </div>
  );
}
