-- ══════════════════════════════════════════════════════════════════
--   PROPIEDADES ENERGY BLESS — CRM
--   Script SQL para crear las tablas en Supabase
--   Copia y pega esto en: Supabase → SQL Editor → New Query → Run
-- ══════════════════════════════════════════════════════════════════

-- ── LEADS ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS leads (
  id          BIGSERIAL PRIMARY KEY,
  nombre      TEXT NOT NULL,
  telefono    TEXT NOT NULL,
  email       TEXT,
  origen      TEXT DEFAULT 'Instagram',
  proyecto    TEXT DEFAULT 'Costa Dorada',
  asesor_id   INT,
  estado      TEXT DEFAULT 'Nuevo',
  fecha       DATE DEFAULT CURRENT_DATE,
  notas       TEXT DEFAULT '',
  created_at  TIMESTAMP DEFAULT NOW()
);

-- ── VISITAS ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS visitas (
  id          BIGSERIAL PRIMARY KEY,
  lead_id     BIGINT REFERENCES leads(id) ON DELETE CASCADE,
  asesor_id   INT,
  proyecto    TEXT,
  fecha       DATE,
  hora        TEXT,
  estado      TEXT DEFAULT 'Pendiente',
  resultado   TEXT DEFAULT '',
  created_at  TIMESTAMP DEFAULT NOW()
);

-- ── RESERVAS ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS reservas (
  id              BIGSERIAL PRIMARY KEY,
  lead_id         BIGINT REFERENCES leads(id) ON DELETE CASCADE,
  asesor_id       INT,
  proyecto        TEXT,
  parcela         TEXT,
  monto           BIGINT DEFAULT 0,
  fecha_reserva   DATE,
  estado          TEXT DEFAULT 'Reserva',
  escritura_fecha DATE,
  notas           TEXT DEFAULT '',
  created_at      TIMESTAMP DEFAULT NOW()
);

-- ── TAREAS ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tareas (
  id          BIGSERIAL PRIMARY KEY,
  asesor_id   INT,
  titulo      TEXT NOT NULL,
  descripcion TEXT DEFAULT '',
  prioridad   TEXT DEFAULT 'Media',
  fecha       DATE DEFAULT CURRENT_DATE,
  estado      TEXT DEFAULT 'Pendiente',
  completada  BOOLEAN DEFAULT FALSE,
  created_at  TIMESTAMP DEFAULT NOW()
);

-- ── DATOS DE EJEMPLO ─────────────────────────────────────────────
INSERT INTO leads (nombre, telefono, email, origen, proyecto, asesor_id, estado, fecha) VALUES
  ('Marco Herrera',   '+56 9 6111 0001', 'marco@gmail.com', 'Instagram',  'Costa Dorada',      1, 'Nuevo',            '2026-05-28'),
  ('Catalina Ramos',  '+56 9 6222 0002', 'cata@gmail.com',  'Facebook',   'Praderas de Caone', 2, 'Contactado',       '2026-05-29'),
  ('Jorge Pinto',     '+56 9 6333 0003', 'jorge@gmail.com', 'Referido',   'Costa Dorada',      1, 'Visita agendada',  '2026-05-30'),
  ('Paola Vera',      '+56 9 6444 0004', 'paola@gmail.com', 'Portal web', 'Valle Verde',       3, 'En negociación',   '2026-06-01');

INSERT INTO tareas (asesor_id, titulo, descripcion, prioridad, fecha) VALUES
  (1, 'Llamar a Marco Herrera sobre Costa Dorada',   'Confirmar visita para el 5 de junio',                    'Alta',  '2026-06-04'),
  (2, 'Enviar información de Praderas de Caone',     'Enviar brochure y precios actualizados a Catalina',      'Media', '2026-06-04'),
  (3, 'Seguimiento post-visita Paola Vera',          'Llamar para avanzar en negociación parcela Valle Verde', 'Alta',  '2026-06-04');

-- ── PERMISOS (Row Level Security desactivado para simplicidad) ───
ALTER TABLE leads    DISABLE ROW LEVEL SECURITY;
ALTER TABLE visitas  DISABLE ROW LEVEL SECURITY;
ALTER TABLE reservas DISABLE ROW LEVEL SECURITY;
ALTER TABLE tareas   DISABLE ROW LEVEL SECURITY;
